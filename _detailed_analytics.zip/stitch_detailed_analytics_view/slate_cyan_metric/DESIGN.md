# Design System Document: The Kinetic Precision Framework

## 1. Overview & Creative North Star
**Creative North Star: "The Obsidian Architect"**

This design system rejects the "flat and boxy" dashboard trope in favor of a high-end, editorial experience. We are building a digital command center that feels like a precision instrument—authoritative, deep, and luminous. 

To move beyond "standard" UI, this system utilizes **Tonal Depth** and **Asymmetric Balance**. We do not use grids to cage data; we use white space to let it breathe. By overlapping high-contrast metrics (`display-lg`) over subtle, glass-like surfaces, we create a sense of three-dimensional space that guides the user’s eye to what matters most: the insight.

---

## 2. Colors: The Luminous Palette
Our palette is built on a "Deep Slate" foundation to establish high-trust professionalism, punctuated by "Electric" accents that signify data vitality.

### Surface Hierarchy & Nesting
Forget the 1px border. We define space through **The "No-Line" Rule**. Boundaries are created exclusively through background shifts using our `surface` tokens.
*   **Base Layer:** Use `surface` (#0b1326) for the overall application background.
*   **Secondary Sections:** Use `surface_container_low` (#131b2e) for large sectioning.
*   **Interactive Cards:** Use `surface_container` (#171f33) or `surface_container_high` (#222a3d) to create a "lifted" feel.

### The "Glass & Gradient" Rule
To elevate the aesthetic, floating elements (like bottom sheets or specialized tooltips) must use **Glassmorphism**. Apply a backdrop-blur (12px–20px) to `surface_variant` at 60% opacity. 

**Signature Texture:** Primary CTAs should not be flat. Use a linear gradient from `primary` (#62e6ff) to `primary_container` (#04cce6) at a 135-degree angle to provide a "lit-from-within" professional polish.

---

## 3. Typography: Editorial Authority
We pair the geometric precision of **Manrope** for high-impact displays with the functional clarity of **Inter** for data density.

*   **The Power Metric (`display-lg`):** Reserved for primary KPIs. Use `primary` or `on_surface` color.
*   **The Narrative (`headline-md`):** Used for section headers. Manrope provides a custom, "premium" feel that distinguishes this from generic dashboards.
*   **The Data Label (`label-md`):** Inter at `0.75rem`. Use `on_surface_variant` (#bac9c9) to create a clear hierarchy between the "Label" and the "Value."

---

## 4. Elevation & Depth: Tonal Layering
We move away from traditional drop shadows toward **Ambient Luminosity**.

*   **The Layering Principle:** Stack `surface_container_lowest` cards on `surface_container_low` backgrounds. This creates a natural, soft-touch depth without visual clutter.
*   **Ambient Shadows:** For high-priority floating elements, use a shadow with a 32px blur, 0px offset, and 6% opacity. The shadow color must be a tinted version of `surface_container_highest` (#2d3449)—never pure black.
*   **The "Ghost Border":** If a separator is required for accessibility, use `outline_variant` (#3b4949) at **15% opacity**. This creates a "suggestion" of a boundary rather than a hard wall.

---

## 5. Components

### Cards & Data Containers
*   **Rule:** Forbid divider lines. Use `spacing-6` (1.3rem) of vertical white space to separate content chunks.
*   **Styling:** Use `xl` (0.75rem) roundedness for a modern, approachable feel. Background should be `surface_container_high`.

### Progress Rings & Line Charts
*   **Progress Rings:** Use `primary` (#62e6ff) for the active track and `surface_container_highest` for the empty track. The stroke should be "round" capped for a premium finish.
*   **Line Charts:** Use a 2px stroke of `secondary` (#adc6ff). Fill the area beneath the line with a gradient transitioning from `secondary` (20% opacity) to `surface` (0% opacity).

### Segmented Controls (Filtering)
*   **Style:** A "pill" container using `surface_container_lowest`. The active segment should be a "floating" `surface_container_highest` pill with a subtle `primary` glow.

### Input Fields
*   **State:** Default state is a "Ghost Border" over `surface_container_low`. 
*   **Focus:** Transition the border to `primary` and add a subtle outer glow (4px blur) of the same color.

### Buttons
*   **Primary:** Gradient (Primary to Primary Container), `full` roundedness. 
*   **Secondary:** Ghost style. Transparent background with a `primary` "Ghost Border" and `primary` text.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use `spacing-10` or `spacing-12` for page margins to create an "editorial" feel.
*   **Do** use `tertiary` (#60eeb1) exclusively for positive growth metrics and `error` (#ffb4ab) for negative trends.
*   **Do** vary font weights. Pair a `headline-lg` (Bold) with a `body-md` (Regular) for immediate visual scanability.

### Don't:
*   **Don't** use pure black (#000000) or pure white (#ffffff). It breaks the sophisticated "Obsidian" depth.
*   **Don't** use 1px solid borders to separate list items. Use tonal shifts or whitespace.
*   **Don't** overcrowd the mobile viewport. If a chart has more than 5 data points, use a horizontal scroll within the card or a "View Details" drill-down.